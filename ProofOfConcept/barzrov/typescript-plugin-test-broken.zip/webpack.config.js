const path = require('path');
const webpack = require('webpack');
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = {
    //target: 'node',
    target: 'web',
    context: __dirname + "/src",
    entry: "./module.ts",
    output: {
        filename: "module.js",
        path: path.resolve(__dirname, 'dist'),
        libraryTarget: "amd"
    },
    node: {
        fs: 'empty',
    },
    externals: [
        // remove the line below if you don't want to use buildin versions
        'jquery', 'lodash', 'moment',
        function(context, request, callback) {
            var prefix = 'grafana/';
            if (request.indexOf(prefix) === 0) {
                return callback(null, request.substr(prefix.length));
            }
            callback();
        }
    ],
    plugins: [
        new webpack.optimize.OccurrenceOrderPlugin(),
        new CopyWebpackPlugin([
            {
                from: 'plugin.json'
            },
            {
                from: "./ProofOfConcept/barzrov/*.json"
            }
        ])
    ],
    resolve: {
        extensions: [".ts", ".js"],
        modules: [
            path.resolve(__dirname, "src/jsbayesLibrary/"),
            path.resolve(__dirname, "src/ProofOfConcept/barzrov/")
        ]
    },
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                loaders: [
                    {
                        loader: "babel-loader",
                        options: { presets: ['env'] }
                    },
                    "ts-loader"
                ],
                exclude: /node_modules/,
            }
        ]
    }
};
