console.log("Test1");
import { PanelCtrl } from 'grafana/app/plugins/sdk';
console.log("Test2");
import {Network, SingleValue} from 'JsonTestScript';
console.log("Test3");

class Ctrl extends PanelCtrl {
    
    static template: string = "<div>Hello from <b>TypeScript Template Plugin</b></div>";
    
    constructor($scope, $injector) {
        super($scope, $injector);
        console.log("---");
        console.log("Starting script - module");
        let SingleValueVar = new SingleValue("ValueNameTest", "lol");
        let Network2 = new Network();
        Network2.addNode("n1", [new SingleValue("False", "0"), new SingleValue("True", "1")], [
            [0.2, 0.8]
        ]);
        Network2.addNode("n2", [new SingleValue("False", "0"), new SingleValue("True", "1")], [
            [0.8, 0.2]
        ]);
        Network2.addNode("n3", [new SingleValue("False", "0"), new SingleValue("True", "1")], []);
        Network2.createLink("n3", "n2");
        Network2.createLink("n3", "n1");
        Network2.setNodeCpt("n3", [
            [0.2, 0.8],
            [0.8, 0.2],
            [0.2, 0.8],
            [0.8, 0.2]
        ]);
        Network2.observe("n3", new SingleValue("False", "0"));
        let samples = 1000;
        let sample_promise = Network2.sample(samples);
        sample_promise.then(function (result) {
            console.log("Sample result:" + result / samples);
        });
        console.log("Done");
        console.log("Single Value:" + SingleValueVar.getName());
        let NetworkJson = new Network("./ProofOfConcept/barzrov/bigNetwork.json");
        sample_promise = NetworkJson.sample(samples);
        sample_promise.then(function (result) {
            console.log("Sample Json result:" + result / samples);
        });
        console.log("Done2");
    }

    link(scope, element) {
    }
  
}

export { Ctrl as PanelCtrl }
